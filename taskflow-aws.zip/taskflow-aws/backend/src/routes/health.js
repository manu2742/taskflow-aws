const router = require('express').Router();
const { query } = require('../db');

// Used by Docker/ALB health checks and CloudWatch alarms.
router.get('/', async (req, res) => {
  try {
    await query('SELECT 1');
    res.json({ status: 'ok', uptime: process.uptime(), db: 'up' });
  } catch (err) {
    res.status(503).json({ status: 'degraded', db: 'down' });
  }
});

module.exports = router;
