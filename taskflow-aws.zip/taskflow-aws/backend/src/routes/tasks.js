const router = require('express').Router();
const { z } = require('zod');
const { query } = require('../db');
const auth = require('../middleware/auth');
const validate = require('../middleware/validate');

const STATUS = z.enum(['todo', 'in_progress', 'done']);

const createSchema = z.object({
  title: z.string().trim().min(1, 'Title is required').max(200),
  description: z.string().max(2000).optional().default(''),
  status: STATUS.optional().default('todo'),
});

const updateSchema = z
  .object({
    title: z.string().trim().min(1).max(200).optional(),
    description: z.string().max(2000).optional(),
    status: STATUS.optional(),
  })
  .refine((v) => Object.keys(v).length > 0, { message: 'Provide at least one field to update' });

const listSchema = z.object({
  status: STATUS.optional(),
  limit: z.coerce.number().int().min(1).max(100).optional().default(20),
  offset: z.coerce.number().int().min(0).optional().default(0),
});

router.use(auth);

// GET /api/tasks?status=todo&limit=20&offset=0
router.get('/', validate(listSchema, 'query'), async (req, res, next) => {
  try {
    const { status, limit, offset } = req.query;
    const params = [req.user.id];
    let where = 'user_id = $1';
    if (status) {
      params.push(status);
      where += ` AND status = $${params.length}`;
    }
    params.push(limit, offset);
    const { rows } = await query(
      `SELECT id, title, description, status, created_at, updated_at
         FROM tasks WHERE ${where}
         ORDER BY created_at DESC
         LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    res.json({ tasks: rows, limit, offset });
  } catch (err) {
    next(err);
  }
});

router.post('/', validate(createSchema), async (req, res, next) => {
  try {
    const { title, description, status } = req.body;
    const { rows } = await query(
      `INSERT INTO tasks (user_id, title, description, status)
       VALUES ($1, $2, $3, $4)
       RETURNING id, title, description, status, created_at, updated_at`,
      [req.user.id, title, description, status]
    );
    res.status(201).json({ task: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.get('/:id(\\d+)', async (req, res, next) => {
  try {
    const { rows } = await query(
      'SELECT id, title, description, status, created_at, updated_at FROM tasks WHERE id = $1 AND user_id = $2',
      [req.params.id, req.user.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Task not found' });
    return res.json({ task: rows[0] });
  } catch (err) {
    return next(err);
  }
});

router.patch('/:id(\\d+)', validate(updateSchema), async (req, res, next) => {
  try {
    const fields = [];
    const params = [];
    for (const key of ['title', 'description', 'status']) {
      if (req.body[key] !== undefined) {
        params.push(req.body[key]);
        fields.push(`${key} = $${params.length}`);
      }
    }
    params.push(req.params.id, req.user.id);
    const { rows } = await query(
      `UPDATE tasks SET ${fields.join(', ')}, updated_at = now()
       WHERE id = $${params.length - 1} AND user_id = $${params.length}
       RETURNING id, title, description, status, created_at, updated_at`,
      params
    );
    if (!rows[0]) return res.status(404).json({ error: 'Task not found' });
    return res.json({ task: rows[0] });
  } catch (err) {
    return next(err);
  }
});

router.delete('/:id(\\d+)', async (req, res, next) => {
  try {
    const { rowCount } = await query('DELETE FROM tasks WHERE id = $1 AND user_id = $2', [
      req.params.id,
      req.user.id,
    ]);
    if (!rowCount) return res.status(404).json({ error: 'Task not found' });
    return res.status(204).end();
  } catch (err) {
    return next(err);
  }
});

module.exports = router;
