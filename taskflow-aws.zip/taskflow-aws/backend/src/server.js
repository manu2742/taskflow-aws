const app = require('./app');
const config = require('./config');
const { initSchema, pool } = require('./db');

async function start() {
  // Retry so the API survives the DB container/RDS starting a bit later.
  for (let attempt = 1; attempt <= 10; attempt += 1) {
    try {
      await initSchema();
      break;
    } catch (err) {
      console.error(`DB not ready (attempt ${attempt}/10): ${err.message}`);
      if (attempt === 10) process.exit(1);
      await new Promise((r) => setTimeout(r, 3000));
    }
  }

  const server = app.listen(config.port, () => {
    console.log(`TaskFlow API listening on :${config.port} (${config.env})`);
  });

  const shutdown = (signal) => {
    console.log(`${signal} received, shutting down`);
    server.close(async () => {
      await pool.end();
      process.exit(0);
    });
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

start();
