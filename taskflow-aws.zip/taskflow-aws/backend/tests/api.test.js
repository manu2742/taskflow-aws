process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test-secret';

const request = require('supertest');
const app = require('../src/app');
const { initSchema, pool } = require('../src/db');

const email = () => `user_${Date.now()}_${Math.random().toString(36).slice(2)}@example.com`;

beforeAll(async () => {
  await initSchema();
});

afterAll(async () => {
  await pool.end();
});

describe('health', () => {
  it('reports ok with the database up', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.db).toBe('up');
  });
});

describe('auth', () => {
  it('registers, rejects duplicates, and logs in', async () => {
    const creds = { email: email(), password: 'password123' };
    const reg = await request(app).post('/api/auth/register').send(creds);
    expect(reg.status).toBe(201);
    expect(reg.body.token).toBeDefined();

    const dup = await request(app).post('/api/auth/register').send(creds);
    expect(dup.status).toBe(409);

    const login = await request(app).post('/api/auth/login').send(creds);
    expect(login.status).toBe(200);

    const bad = await request(app).post('/api/auth/login').send({ ...creds, password: 'wrongpass1' });
    expect(bad.status).toBe(401);
  });

  it('validates input', async () => {
    const res = await request(app).post('/api/auth/register').send({ email: 'nope', password: '123' });
    expect(res.status).toBe(400);
    expect(res.body.details.length).toBeGreaterThan(0);
  });
});

describe('tasks', () => {
  let token;
  beforeAll(async () => {
    const res = await request(app).post('/api/auth/register').send({ email: email(), password: 'password123' });
    token = res.body.token;
  });
  const authed = (req) => req.set('Authorization', `Bearer ${token}`);

  it('requires authentication', async () => {
    const res = await request(app).get('/api/tasks');
    expect(res.status).toBe(401);
  });

  it('supports full CRUD', async () => {
    const created = await authed(request(app).post('/api/tasks')).send({ title: 'Write tests' });
    expect(created.status).toBe(201);
    const id = created.body.task.id;
    expect(created.body.task.status).toBe('todo');

    const list = await authed(request(app).get('/api/tasks?status=todo'));
    expect(list.status).toBe(200);
    expect(list.body.tasks.some((t) => t.id === id)).toBe(true);

    const updated = await authed(request(app).patch(`/api/tasks/${id}`)).send({ status: 'done' });
    expect(updated.status).toBe(200);
    expect(updated.body.task.status).toBe('done');

    const del = await authed(request(app).delete(`/api/tasks/${id}`));
    expect(del.status).toBe(204);

    const gone = await authed(request(app).get(`/api/tasks/${id}`));
    expect(gone.status).toBe(404);
  });

  it('rejects invalid payloads', async () => {
    const res = await authed(request(app).post('/api/tasks')).send({ title: '' });
    expect(res.status).toBe(400);
  });

  it("does not expose another user's tasks", async () => {
    const created = await authed(request(app).post('/api/tasks')).send({ title: 'Private' });
    const other = await request(app).post('/api/auth/register').send({ email: email(), password: 'password123' });
    const res = await request(app)
      .get(`/api/tasks/${created.body.task.id}`)
      .set('Authorization', `Bearer ${other.body.token}`);
    expect(res.status).toBe(404);
  });
});
