# API Reference

Base URL: `/api` (e.g. `http://localhost/api`). JSON in, JSON out.
Protected routes need `Authorization: Bearer <token>`.

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/health` | no | Liveness + database check |
| POST | `/auth/register` | no | Create account. Body: `{ "email", "password" (min 8) }` -> `201 { user, token }` |
| POST | `/auth/login` | no | Body: `{ "email", "password" }` -> `200 { user, token }` |
| GET | `/tasks` | yes | Query: `status` (todo/in_progress/done), `limit` (1-100), `offset` |
| POST | `/tasks` | yes | Body: `{ "title", "description"?, "status"? }` -> `201 { task }` |
| GET | `/tasks/:id` | yes | One task (own tasks only) |
| PATCH | `/tasks/:id` | yes | Partial update of `title`, `description`, `status` |
| DELETE | `/tasks/:id` | yes | `204` on success |

Errors: `400` validation (with `details`), `401` auth, `404` not found, `409` duplicate email, `429` rate limited, `500` server.

## Example

```bash
TOKEN=$(curl -s -X POST localhost/api/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"email":"me@example.com","password":"password123"}' | jq -r .token)

curl -s -X POST localhost/api/tasks \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"title":"Deploy to AWS"}'
```
