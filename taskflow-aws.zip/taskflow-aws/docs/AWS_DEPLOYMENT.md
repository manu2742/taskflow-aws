# Deploying TaskFlow on AWS (EC2 + RDS + CloudWatch)

Architecture: **Browser -> EC2 (nginx container -> Node API container) -> RDS PostgreSQL**.
Logs go to **CloudWatch Logs**. Access is controlled with **IAM** and **security groups**.

## 1. RDS PostgreSQL
1. RDS -> Create database -> PostgreSQL 16, `db.t4g.micro` (free-tier eligible where available).
2. Set a master username/password. Database name: `taskflow`. Public access: **No**.
3. Create a security group `taskflow-db-sg` that allows inbound **5432 only from `taskflow-ec2-sg`**.

## 2. EC2 instance
1. Launch Ubuntu 24.04, `t3.micro`/`t2.micro`. Create/download a key pair.
2. Security group `taskflow-ec2-sg`: inbound **22** (your IP only) and **80** (anywhere).
3. IAM: create a role `taskflow-ec2-role` with permission to write CloudWatch Logs
   (`logs:CreateLogGroup`, `logs:CreateLogStream`, `logs:PutLogEvents`) and attach it to the instance.
4. SSH in and install Docker:
   ```bash
   sudo apt update && sudo apt install -y docker.io docker-compose-v2 git curl
   sudo usermod -aG docker $USER && newgrp docker
   ```

## 3. First deploy
```bash
git clone https://github.com/<your-username>/taskflow-aws.git ~/taskflow-aws
cd ~/taskflow-aws
cp .env.example .env
nano .env     # set JWT_SECRET, DATABASE_URL (RDS endpoint), AWS_REGION
docker compose -f docker-compose.prod.yml up -d --build
curl http://localhost/api/health
```
Open `http://<EC2-public-IP>` in a browser.

## 4. CI/CD with GitHub Actions
Repo -> Settings -> Secrets and variables -> Actions -> add:
`EC2_HOST`, `EC2_USER` (`ubuntu`), `EC2_SSH_KEY` (contents of the `.pem`).
Every push to `main` runs tests (CI), then SSH-deploys via `scripts/deploy.sh` and fails if `/api/health` is not healthy.

## 5. Monitoring
CloudWatch -> Log groups -> `taskflow-backend` / `taskflow-frontend`.
Optional: create a metric filter on `ERROR` and an alarm that emails you via SNS.

## Hardening checklist
- HTTPS: put an Application Load Balancer + ACM certificate in front, or use Caddy/certbot on the instance.
- Restrict `CORS_ORIGIN` to your real domain.
- Rotate `JWT_SECRET`; never commit `.env`.
- Take RDS automated backups; use an Elastic IP so the address does not change.
- Stop/delete resources when done to avoid charges.
