import { useCallback, useEffect, useState } from 'react';
import { api, getToken, setToken } from './api.js';

const STATUSES = [
  { value: 'todo', label: 'To do' },
  { value: 'in_progress', label: 'In progress' },
  { value: 'done', label: 'Done' },
];

function AuthForm({ onAuthed }) {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const fn = mode === 'login' ? api.login : api.register;
      const { token } = await fn(email, password);
      setToken(token);
      onAuthed();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="card" onSubmit={submit}>
      <h2>{mode === 'login' ? 'Sign in' : 'Create account'}</h2>
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      <input
        type="password"
        placeholder="Password (min 8 characters)"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        minLength={8}
        required
      />
      {error && <p className="error">{error}</p>}
      <button disabled={busy}>{busy ? 'Please wait...' : mode === 'login' ? 'Sign in' : 'Register'}</button>
      <p className="muted">
        {mode === 'login' ? 'No account?' : 'Already registered?'}{' '}
        <a href="#" onClick={(e) => { e.preventDefault(); setMode(mode === 'login' ? 'register' : 'login'); }}>
          {mode === 'login' ? 'Register' : 'Sign in'}
        </a>
      </p>
    </form>
  );
}

function Tasks({ onLogout }) {
  const [tasks, setTasks] = useState([]);
  const [filter, setFilter] = useState('');
  const [title, setTitle] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const { tasks: rows } = await api.listTasks(filter);
      setTasks(rows);
      setError('');
    } catch (err) {
      if (/token/i.test(err.message)) onLogout();
      else setError(err.message);
    }
  }, [filter, onLogout]);

  useEffect(() => { load(); }, [load]);

  async function add(e) {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      await api.createTask({ title });
      setTitle('');
      load();
    } catch (err) { setError(err.message); }
  }

  const change = (id, patch) => api.updateTask(id, patch).then(load).catch((e) => setError(e.message));
  const remove = (id) => api.deleteTask(id).then(load).catch((e) => setError(e.message));

  return (
    <div>
      <div className="row">
        <h2>My tasks</h2>
        <button className="link" onClick={onLogout}>Sign out</button>
      </div>
      <form className="row" onSubmit={add}>
        <input placeholder="New task title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <button>Add</button>
      </form>
      <select value={filter} onChange={(e) => setFilter(e.target.value)}>
        <option value="">All statuses</option>
        {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
      </select>
      {error && <p className="error">{error}</p>}
      <ul className="tasks">
        {tasks.length === 0 && <li className="muted">No tasks yet.</li>}
        {tasks.map((t) => (
          <li key={t.id}>
            <span className={t.status === 'done' ? 'done' : ''}>{t.title}</span>
            <select value={t.status} onChange={(e) => change(t.id, { status: e.target.value })}>
              {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
            <button className="link danger" onClick={() => remove(t.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function App() {
  const [authed, setAuthed] = useState(Boolean(getToken()));
  const logout = useCallback(() => { setToken(null); setAuthed(false); }, []);
  return (
    <main>
      <h1>TaskFlow</h1>
      {authed ? <Tasks onLogout={logout} /> : <AuthForm onAuthed={() => setAuthed(true)} />}
    </main>
  );
}
