#!/usr/bin/env bash
# Runs ON the EC2 instance. Pulls the latest code and restarts the stack.
set -euo pipefail

APP_DIR="${APP_DIR:-$HOME/taskflow-aws}"
cd "$APP_DIR"

git fetch --all --prune
git reset --hard origin/main

docker compose -f docker-compose.prod.yml up -d --build
docker image prune -f

# Smoke test: fail the deploy if the API is not healthy.
for i in $(seq 1 15); do
  if curl -fsS http://localhost/api/health >/dev/null; then
    echo "Deploy OK"
    exit 0
  fi
  sleep 3
done
echo "Health check failed" >&2
docker compose -f docker-compose.prod.yml logs --tail=50 backend >&2
exit 1
